# GBA Player para Android

Emulador de Game Boy Advance para Android, com interface touch e suporte a ROMs `.gba` escolhidas pelo usuário. O projeto inclui o motor JavaScript GBA.js (BSD-2-Clause) dentro do APK e não distribui jogos comerciais.

## O que já funciona

- CPU ARM7TDMI, memória, vídeo, áudio, timers, interrupções e keypad via GBA.js.
- Seleção de ROM `.gba` pelo seletor nativo do Android.
- Controles touch: direcional, A, B, L, R, Start e Select.
- Controles físicos/teclado com setas, Z (A), X (B), A (L), S (R), Enter (Start) e\\ (Select).
- Save automático no armazenamento local do WebView.
- Importação de `.sav`/`.dat` e exportação do save pelo seletor nativo do Android.
- Captura de tela em PNG pelo seletor nativo.
- Pausar, reiniciar, volume, som e modo pixelado.
- Compatibilidade com gamepads suportados pelo WebView.

## Gerar o APK

1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute **Build > Build APK(s)**.
4. Instale `app/build/outputs/apk/debug/app-debug.apk` em um aparelho Android 6.0 ou superior.

Também é possível usar o workflow `Build APK` em `.github/workflows/build-apk.yml` para gerar o APK no GitHub Actions.

## Uso

1. Abra o app e toque em **ABRIR JOGO**.
2. Escolha uma ROM `.gba` descompactada.
3. Use os controles na tela ou um controle físico.
4. Para continuar um jogo, importe o `.sav` correspondente antes de iniciar a ROM.

Use somente ROMs e saves que você possui legalmente. O motor incluído está documentado em `THIRD_PARTY_LICENSE_GBAJS.txt`.
